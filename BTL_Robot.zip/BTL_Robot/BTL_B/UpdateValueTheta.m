function [theta1,theta2,d3,theta4] = UpdateValueTheta(handles)
theta1 = 0;
theta2 = 90;
d3 = 0;
theta4 = 0;
end