global myScara
global t1
[theta1_max,theta2_max,d3_max,theta4_max] = myScara.InverseKinematic(myScara,0.2,-0.4,0.05783,90/180*pi);
[Theta1_m,Theta1_dot_m,Theta1_2dot_m,t1] = Trapezoidal(theta1_max-myScara.theta(1),20,20);

set_param('PIDController_Cascaded/motor1/Integrator','InitialCondition',num2str(0));

sig1 = [t1;Theta1_m];

save theta1set.mat sig1;

set_param('PIDController_Cascaded','StopTime',num2str(t1(end)));
set_param('PIDController_Cascaded','SimulationCommand','start');

