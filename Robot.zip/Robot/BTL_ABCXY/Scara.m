classdef Scara
    properties
        a;
        d;
        alpha; % deg
        theta; % deg
        pos;
        orien;  % (rad)
    end
    methods(Static)
        function robot = Scara(handles, theta1, theta2, d3, theta4)          
            robot.d = [0.179; 0; 0; 0];
            robot.theta = [0.00; 90.00; 0.00; 0.00];
            robot.a = [0.2; 0.3; 0; 0];
            robot.alpha = [0.00; 0.00; 0.00; 180];
            
            robot.d(3)= d3;
            robot.theta(1)=theta1;
            robot.theta(2)=theta2;
            robot.theta(4)=theta4;
            [robot.pos,robot.orien] = robot.ForwardKinematic(robot);  
        end
        %% Ham tinh dong hoc thuan
        function [p_robot,o_robot] = ForwardKinematic(self)
            a = self.a;
            alpha = self.alpha*pi/180;
            d = self.d;
            theta = self.theta*pi/180;
            % Input: DH Parameter
            % Output: joint position p1 p2 p3 p4     (x y z)
            %         joint orientation o1 o2 o3 o4  (roll pitch yaw)
            % Ma tran Denavit_Hartenberg
            A0_1 = Ma_Tran(a(1),alpha(1),d(1),theta(1)) ;
            A1_2 = Ma_Tran(a(2),alpha(2),d(2),theta(2)) ;
            A2_3 = Ma_Tran(a(3),alpha(3),d(3),theta(3)) ;
            A3_4 = Ma_Tran(a(4),alpha(4),d(4),theta(4)) ;

            A0_2=A0_1*A1_2;
            A0_3=A0_1*A1_2*A2_3;
            A0_4=A0_1*A1_2*A2_3*A3_4;

            p0 = [0;0;0];
            [p1, o1] = Posi_Orien(A0_1,p0);           %Joint1: p1 = [a1*cos(theta1); a1*sin(theta1); d1] (x1,y1,z1) va (roll_1 pitch_1 yaw_1)
            [p2, o2] = Posi_Orien(A0_2,p0);           %Joint2: p2 = [a2*cos(theta2); a2*sin(theta2); d2] (x2,y2,z2) va (roll_2 pitch_2 yaw_2)
            [p3, o3] = Posi_Orien(A0_3,p0);           %Joint3: p3 = [a3*cos(theta3); a3*sin(theta3); d3] (x3,y3,z3) va (roll_3 pitch_3 yaw_3)
            [p4, o4] = Posi_Orien(A0_4,p0);           %Joint4: p4 = [a4*cos(theta4); a4*sin(theta4); d4] (x4,y4,z4) va (roll_4 pitch_4 yaw_4)

            p_robot = [p1 p2 p3 p4]';
            o_robot = [o1; o2; o3; o4];
        end
        
        %% Ham tinh dong hoc nguoc
        function [the1,the2,d3,the4] = InverseKinematic(robot,x,y,z,yaw)
            % Input: x y z yaw
            % Output: theta1 theta2 d3 theta4
            a = robot.a;
            d = robot.d;
            theta1_max = 125;
            theta2_max = 145;
            d3_max = 0.15;
            theta4_max = 360;   %+-360
            c2 = (x^2 + y^2 - a(1)^2 - a(2)^2)/(2*a(1)*a(2));
            % Theta2 = +- acos(c2)   
            if (abs(c2)<= 1)
                if x > 0 theta2 = acos(c2);
                elseif x<0 && y>=0 theta2 = acos(c2);
                else theta2 = -acos(c2);
                end
                s2 = sin(theta2);
                               
                %C1 = |X B1; Y B2|/|A1 B1; A2 B2|
                %S1 = |A1 X;A2 Y|/|A1 B1; A2 B2|
                c1 = (x*(a(1)+a(2)*c2)+a(2)*s2*y)/(x*x + y*y);
                s1 = ((a(1)+a(2)*c2)*y - x*a(2)*s2)/(x*x + y*y);
                theta1 = atan2(s1,c1);
                if y < 0
                     if theta1 < -theta1_max*pi/180
                            s2 = sin(theta2);
                            c2 = cos(theta2);
                            c1 = (x*(a(1)+a(2)*c2)+a(2)*s2*y)/(x*x + y*y);
                            s1 = ((a(1)+a(2)*c2)*y - x*a(2)*s2)/(x*x + y*y);
                            theta1 = atan2(s1,c1);
                     end               
                end               
                d33 = z - d(1)-d(4);
                theta4 = yaw - (theta1 + theta2);                
                if (abs(theta1*180/pi)>theta1_max)||(abs(theta2*180/pi)>theta2_max)||(d33<-d3_max) || abs(theta4*180/pi)>theta4_max
                    the1 = 0;
                    the2 = 90;
                    d3 = 0;
                    the4 = 0;
                    h=questdlg('Ngoai vung workspace','Warning','OK','OK');
                    return
                else
                    the1 = theta1*180/pi;
                    the2 = theta2*180/pi;
                    d3 = d33;
                    the4 = theta4*180/pi;
                end
            else
                the1 = 0;
                the2 = 90;
                d3 = 0;
                the4 = 0;
                h=questdlg('Ngoai vung workspace','Warning','OK','OK');
                return
            end
        end
        
        %% Kinematic Singularity
         function Singu = KinematicSingularity(a,alpha,d,theta)            
            J = Jacobian(a,alpha,d,theta);
            %% Kiem tra singularity
            J = J(1:3,1:3);
            if abs(det(J)) <= 10e-4
               Singu = 1;
            else
               Singu = 0;
            end
         end
    end
end