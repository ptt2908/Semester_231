function Simulink_PID(t1,Theta1_m,Theta2_m,d3_m,Theta4_m)
set_param('PIDController_Cascaded/motor1/Integrator','InitialCondition',num2str(0));
set_param('PIDController_Cascaded/motor2/Integrator','InitialCondition',num2str(0));
set_param('PIDController_Cascaded/motor3/Integrator','InitialCondition',num2str(0));
set_param('PIDController_Cascaded/motor4/Integrator','InitialCondition',num2str(0));

sig1 = [t1;Theta1_m];
sig2 = [t1;Theta2_m];
sig3 = [t1;d3_m];
sig4 = [t1;Theta4_m];
save theta1set.mat sig1;
save theta2set.mat sig2;
save d3set.mat sig3;
save theta4set.mat sig4;

% fixed_step_size = t1(end)/500;
set_param('PIDController_Cascaded','StopTime',num2str(t1(end)));
set_param('PIDController_Cascaded', 'FixedStep', num2str(0.02));
set_param('PIDController_Cascaded','SimulationCommand','start');
