function [pre_theta1,pre_theta2,pre_d3,pre_theta4] = UpdateValueTheta(theta1,theta2,d3,theta4)
pre_theta1 = theta1;
pre_theta2 = theta2;
pre_d3 = d3;
pre_theta4 = theta4;
end