function ResetRobot(handles)

set(handles.sld__FW_t1, 'value', 0);
set(handles.sld__FW_t2, 'value', 90);
set(handles.sld__FW_d3, 'value', 0);
set(handles.sld__FW_t4, 'value', 0);

set(handles.vl__FW_t1,'String',0);
set(handles.vl__FW_t2,'String',90);
set(handles.vl__FW_d3,'String',0);
set(handles.vl__FW_t4,'String',0);

set(handles.vl__FW_x,'String',0.2);
set(handles.vl__FW_y,'String',0.3);
set(handles.vl__FW_z,'String',0.179);
set(handles.vl__FW_yaw,'String',90);
