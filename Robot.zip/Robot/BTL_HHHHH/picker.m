function picker(handles,x,y,z,yaw,w,h)
% Ve Joint 4, tay cam vat 
plot3(handles.robot_plot, [x-w/2*cos(yaw), x+w/2*cos(yaw)],[y-w/2*sin(yaw), y+w/2*sin(yaw)],[z, z],'linewidth',3,'color',[0.9220 0.5290 0.1250]);
plot3(handles.robot_plot, [x-w/2*cos(yaw), x-w/2*cos(yaw)],[y-w/2*sin(yaw), y-w/2*sin(yaw)],[z, z-h],'linewidth',3,'color',[0.9220 0.5290 0.1250]);
plot3(handles.robot_plot, [x+w/2*cos(yaw), x+w/2*cos(yaw)],[y+w/2*sin(yaw), y+w/2*sin(yaw)],[z, z-h],'linewidth',3,'color',[0.9220 0.5290 0.1250]);