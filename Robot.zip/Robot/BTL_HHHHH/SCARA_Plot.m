classdef SCARA_Plot
    %UNTITLED2 Summary of this class goes here
    %   Detailed explanation goes here
    properties
        %% DH parameter
        a;
        d;
        alpha;  % unit deg
        theta;  % unit deg
        
        %% Limatation of workspace
        pos;    %%position of 4 joints 1 2 3 4
        orien;  %%orientation of 4 joints 1 2 3 4, unit radian
    end
    
    methods(Static)
        function obj = SCARA_Plot(handles, theta1, theta2, d3, theta4)
            obj.a = [0.2; 0.3; 0; 0];
            obj.d = [0.179; 0; 0; 0];
            obj.alpha = [0.00; 0.00; 0.00; 180];
            obj.theta = [0.00; 90.00; 0.00; 0.00];
            obj.d(3)=d3;
            obj.theta(1)=theta1;
            obj.theta(2)=theta2;
            obj.theta(4)=theta4;
            [obj.pos,obj.orien] = obj.ForwardKinematic(obj);  
        end
        
        function [p_robot,o_robot] = ForwardKinematic(self)
            a = self.a;
            alpha = self.alpha*pi/180;
            d = self.d;
            theta = self.theta*pi/180;
            
            %% Ham tinh dong hoc thuan cua robot
            % Input: DH Parameter
            % Output: joint position p1 p2 p3 p4     (x y z)
            %         joint orientation o1 o2 o3 o4  (roll pitch yaw)
            %% FK Matrix
            A0_1 = Link_matrix(a(1),alpha(1),d(1),theta(1)) ;
            A1_2 = Link_matrix(a(2),alpha(2),d(2),theta(2)) ;
            A2_3 = Link_matrix(a(3),alpha(3),d(3),theta(3)) ;
            A3_4 = Link_matrix(a(4),alpha(4),d(4),theta(4)) ;

            A0_2=A0_1*A1_2;
            A0_3=A0_1*A1_2*A2_3;
            A0_4=A0_1*A1_2*A2_3*A3_4;   % Te

            p0 = [0;0;0];
            [p1, o1] = cal_pose(A0_1,p0);
            [p2, o2] = cal_pose(A0_2,p0);
            [p3, o3] = cal_pose(A0_3,p0);
            [p4, o4] = cal_pose(A0_4,p0);

            p_robot = [p1 p2 p3 p4]';
            o_robot = [o1; o2; o3; o4];
        end
        %% Ham tinh dong hoc nguoc cua robot
        function [the1,the2,d3,the4] = InverseKinematic(obj,x,y,z,yaw)
            % Input: x y z yaw a1 a2
            % Output: theta1 theta2 d3 theta4
            a = obj.a;
            d = obj.d;
            theta1_max = 125;
            theta2_max = 145;
            d3_max = 0.3;

            c2 = (x^2 + y^2 - a(1)^2 - a(2)^2)/(2*a(1)*a(2));
            if (abs(c2)<=1)
                s2 = sqrt(1-c2^2);
                theta21 = atan2(s2,c2);
                theta22 = atan2(-s2,c2);
                
                if abs(theta21 - pi/2) < pi
                    theta2 = theta21;
                else
                    theta2 = theta22;
                    s2 = -s2;
                end

                t1 = [a(1)+a(2)*c2 -a(2)*s2;a(2)*s2 a(1)+a(2)*c2]^(-1)*[x;y];
                c1 = t1(1);
                s1 = t1(2);
                theta1 = atan2(s1,c1);

                d33 = z - d(1);
                theta4 = yaw - ( theta1 + theta2 );
                
                if (abs(theta1*180/pi)>theta1_max)||(abs(theta2*180/pi)>theta2_max)||(d33<-d3_max)
                    h=questdlg('Workspace Singularity','Warning','OK','OK');
                    return
                else
                    the1 = theta1*180/pi;
                    the2 = theta2*180/pi;
                    d3 = d33;
                    the4 = theta4*180/pi;
                end
            else
%                 h=questdlg('Workspace Singularity','Warning','OK','OK');
                return
            end
        end
   
        
        
        function singularity = KinematicSingularity(obj)
            a = obj.a;
            alpha = obj.alpha/180*pi;
            d = obj.d;
            theta = obj.theta/180*pi;

            A01 = Link_matrix(a(1),alpha(1),d(1),theta(1));
            A12 = Link_matrix(a(2),alpha(2),d(2),theta(2));
            A23 = Link_matrix(a(3),alpha(3),d(3),theta(3));
            A34 = Link_matrix(a(4),alpha(4),d(4),theta(4));

            A02 = A01*A12;
            A03 = A02*A23;
            A04 = A03*A34;
            
            z0 = [0 0 1]';
            p0 = [0 0 0]';

            z1 = A01(1:3,3);
            z2 = A02(1:3,3);
            z3 = A03(1:3,3);
            z4 = A04(1:3,3);

            p1 = A01(1:3,4);
            p2 = A02(1:3,4);
            p3 = A03(1:3,4);
            p4 = A04(1:3,4);

            %% Khop 1 xoay, khop 2 xoay, khop 3 tinh tien, khop 4 xoay
            J = [cross(z0,p4-p0) cross(z1,p4-p1) z2 cross(z3,p4-p3);
                 z0 z1 [0;0;0] z3];
            J = J(1:3,1:3);
            det(J)
            if abs(det(J)) <= 10e-4
                singularity = 1;
            else
                singularity = 0;
            end
        end
    end
end

