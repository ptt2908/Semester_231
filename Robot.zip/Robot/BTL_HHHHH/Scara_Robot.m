function varargout = Scara_Robot(varargin)
% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Scara_Robot_OpeningFcn, ...
                   'gui_OutputFcn',  @Scara_Robot_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

% --- Executes just before Scara_Robot is made visible.
function Scara_Robot_OpeningFcn(hObject, eventdata, handles, varargin)
% Choose default command line output for Scara_Robot
set(handles.pn_FW,'Visible','on');

global myScara;
global plot_pos;

% SCARA(handles,a1,a2,d1,t1_max,t2_max,d3_max) TOSHIBA THL500
myScara = SCARA_Plot(handles,0, 90, 0, 0);
plot_pos = [];

handles.output = hObject;
guidata(hObject, handles);

set(handles.vl__FW_x,'String',num2str(myScara.pos(4,1)));
set(handles.vl__FW_y,'String',num2str(myScara.pos(4,2)));
set(handles.vl__FW_z,'String',num2str(myScara.pos(4,3)));
set(handles.vl__FW_yaw,'String',num2str(myScara.orien(4,3)*180/pi));

UpdateRobot(myScara,handles,20,25); 

% --- Outputs from this function are returned to the command line.
function varargout = Scara_Robot_OutputFcn(hObject, eventdata, handles) 
varargout{1} = handles.output;

% --- Executes on button press in cb_view_ws.
function cb_view_ws_Callback(hObject, eventdata, handles)
global myScara
if get(hObject, 'Value')
    PlotWorkspace(myScara,handles);
else
    UpdateRobot(myScara,handles,20,25);  
end


% --- Executes on button press in cb_show_coor.
function cb_show_coor_Callback(hObject, eventdata, handles)
global myScara
if get(hObject, 'Value')
    axes(handles.robot_plot);
    % plot coordinate
    A0_1 = Link_matrix(myScara.a(1),myScara.alpha(1)*pi/180,myScara.d(1),myScara.theta(1)*pi/180) ;
    A1_2 = Link_matrix(myScara.a(2),myScara.alpha(2)*pi/180,myScara.d(2),myScara.theta(2)*pi/180) ;
    A2_3 = Link_matrix(myScara.a(3),myScara.alpha(3)*pi/180,myScara.d(3),myScara.theta(3)*pi/180) ;
    A3_4 = Link_matrix(myScara.a(4),myScara.alpha(4)*pi/180,myScara.d(4),myScara.theta(4)*pi/180) ;
    A0_0=[1 0 0 0; 0 1 0 0; 0 0 1 0; 0 0 0 1];
    A0_2=A0_1*A1_2;
    A0_3=A0_1*A1_2*A2_3;
    A0_4=A0_1*A1_2*A2_3*A3_4;   % Te

    plot_coordinate(0,0,0+myScara.d(1)*5/4,A0_0,'0');
    plot_coordinate(myScara.pos(1,1),myScara.pos(1,2),myScara.pos(1,3)+myScara.d(1)*4/4,A0_1,'1');
    plot_coordinate(myScara.pos(2,1),myScara.pos(2,2),myScara.pos(2,3)+myScara.d(1)*4/4,A0_2,'2');
    plot_coordinate(myScara.pos(3,1),myScara.pos(3,2),myScara.pos(3,3)+myScara.d(1)*4/4,A0_3,'3');
    plot_coordinate(myScara.pos(4,1),myScara.pos(4,2),myScara.pos(4,3)+myScara.d(1)*2/4,A0_4,'4');
else
    UpdateRobot(myScara,handles,20,25); 
end

% --- Executes on button press in btn_Forward.
function btn_Forward_Callback(hObject, eventdata, handles)
global myScara;
x = [];y = [];z = [];
[theta1_1,theta2_1,d3_1,theta4_1] = UpdateValueTheta(handles);
theta1 = get(handles.sld__FW_t1,'value');
theta2 = get(handles.sld__FW_t2,'value');
d3 = get(handles.sld__FW_d3,'value');
theta4 = get(handles.sld__FW_t4,'value');

dentaltheta1 = theta1-theta1_1;
dentaltheta2 = theta2-theta2_1;
dentald3 = d3-d3_1;
dentaltheta4 = theta4-theta4_1;
%SCARA_Plot(handles, theta1, theta2, d3, theta4)
for i=1:1:30
 myScara = SCARA_Plot(handles,theta1_1+dentaltheta1*i/30,theta2_1+dentaltheta2*i/30,d3_1+dentald3*i/30,theta4_1+dentaltheta4*i/30);
 UpdateRobot(myScara,handles,20,25);
 pause(0.1);
set(handles.vl__FW_x,'String',num2str(myScara.pos(4,1)));
set(handles.vl__FW_y,'String',num2str(myScara.pos(4,2)));
set(handles.vl__FW_z,'String',num2str(myScara.pos(4,3)));
set(handles.vl__FW_yaw,'String',num2str(myScara.orien(4,3)*180/pi));
x = [x,myScara.pos(4,1)];
y = [y,myScara.pos(4,2)];
z = [z,myScara.pos(4,3)];
end
plot3(handles.robot_plot,x,y,z,'r','LineWidth',1.5);
% --- Executes on slider movement.
function sld__FW_t1_Callback(hObject, eventdata, handles)
theta1 = get(handles.sld__FW_t1,'value');
set(handles.vl__FW_t1,'string',num2str(theta1));

% --- Executes during object creation, after setting all properties.
function sld__FW_t1_CreateFcn(hObject, eventdata, handles)
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function sld__FW_t2_Callback(hObject, eventdata, handles)
theta(2) = get(handles.sld__FW_t2,'value');
set(handles.vl__FW_t2,'string',num2str(theta(2)));

% --- Executes during object creation, after setting all properties.
function sld__FW_t2_CreateFcn(hObject, eventdata, handles)
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end

% --- Executes on slider movement.
function sld__FW_d3_Callback(hObject, eventdata, handles)
d3 = get(handles.sld__FW_d3,'value');
set(handles.vl__FW_d3,'string',num2str(d3));

% --- Executes during object creation, after setting all properties.
function sld__FW_d3_CreateFcn(hObject, eventdata, handles)
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end

% --- Executes on slider movement.
function sld__FW_t4_Callback(hObject, eventdata, handles)
theta4 = get(handles.sld__FW_t4,'value');
set(handles.vl__FW_t4,'string',num2str(theta4));

% --- Executes during object creation, after setting all properties.
function sld__FW_t4_CreateFcn(hObject, eventdata, handles)
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end



function vl__FW_t1_Callback(hObject, eventdata, handles)
theta(1) = str2double(get(handles.vl__FW_t1,'String'));
set(handles.sld__FW_t1, 'value', theta(1));

% --- Executes during object creation, after setting all properties.
function vl__FW_t1_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function vl__FW_t2_Callback(hObject, eventdata, handles)
theta(2) = str2double(get(handles.vl__FW_t2,'String'));
set(handles.sld__FW_t2, 'value', theta(2));
% --- Executes during object creation, after setting all properties.
function vl__FW_t2_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function vl__FW_d3_Callback(hObject, eventdata, handles)
d(3) = str2double(get(handles.vl__FW_d3,'String'));
set(handles.sld__FW_d3, 'value', d(3));

% --- Executes during object creation, after setting all properties.
function vl__FW_d3_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function vl__FW_t4_Callback(hObject, eventdata, handles)
theta4 = str2double(get(handles.vl__FW_t4,'String'));
set(handles.sld__FW_t4, 'value', theta4);

% --- Executes during object creation, after setting all properties.
function vl__FW_t4_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in btn_FW_reset.
function btn_FW_reset_Callback(hObject, eventdata, handles)
global myScara;
ResetRobot(handles);
myScara.theta(1) = 0;
myScara.theta(2) = 90;
myScara.d(3) = 0;
myScara.theta(4) = 0;
[myScara.pos,myScara.orien] = myScara.ForwardKinematic(myScara)
UpdateRobot(myScara,handles,20,25); 

function vl__FW_x_Callback(hObject, eventdata, handles)

% --- Executes during object creation, after setting all properties.
function vl__FW_x_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function vl__FW_y_Callback(hObject, eventdata, handles)

% --- Executes during object creation, after setting all properties.
function vl__FW_y_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function vl__FW_z_Callback(hObject, eventdata, handles)
% --- Executes during object creation, after setting all properties.
function vl__FW_z_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function vl__FW_yaw_Callback(hObject, eventdata, handles)

% --- Executes during object creation, after setting all properties.
function vl__FW_yaw_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in btn_Inverse.
function btn_Inverse_Callback(hObject, eventdata, handles)
global myScara;
x = str2double(get(handles.vl__FW_x,'String'));
y = str2double(get(handles.vl__FW_y,'String'));
z = str2double(get(handles.vl__FW_z,'String'));
yaw = str2double(get(handles.vl__FW_yaw,'String'));
[theta1_1,theta2_1,d3_1,theta4_1] = UpdateValueTheta(handles);
xx = [];yy = [];zz = [];
tmpScara = myScara;
[theta1,theta2,d3,theta4] = tmpScara.InverseKinematic(tmpScara,x,y,z,yaw*pi/180);
dentaltheta1 = theta1-theta1_1;
dentaltheta2 = theta2-theta2_1;
dentald3 = d3-d3_1;
dentaltheta4 = theta4-theta4_1;
for i=1:1:30
 myScara = SCARA_Plot(handles,theta1_1+dentaltheta1*i/30,theta2_1+dentaltheta2*i/30,d3_1+dentald3*i/30,theta4_1+dentaltheta4*i/30);
 UpdateRobot(myScara,handles,20,25);
 pause(0.1);
 set(handles.vl__FW_t1,'String',theta1*i/30);
set(handles.vl__FW_t2,'String',theta2*i/30);
set(handles.vl__FW_d3,'String',d3*i/30);
set(handles.vl__FW_t4,'String',theta4*i/30);
xx = [xx,myScara.pos(4,1)];
yy = [yy,myScara.pos(4,2)];
zz = [zz,myScara.pos(4,3)];
end
plot3(handles.robot_plot,xx,yy,zz,'r','LineWidth',1.5);
