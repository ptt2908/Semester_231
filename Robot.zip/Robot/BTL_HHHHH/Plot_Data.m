%function Plot_Data(robot,handles)
%x = get(handles.vl__FW_x,'String');
%y = get(handles.vl__FW_y,'String');
%z = get(handles.vl__FW_z,'String');
%plot3(handles.robot_plot,x,y,z,'r');
%end
x = [];y = [];; z = [];
for i=1:1:30
   x = [x,i];
   y = [y,i+1];
   z = [z,i+2];
end
plot3(x,y,z,'r');
