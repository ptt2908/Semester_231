function varargout = Robot_Scara(varargin)
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Robot_Scara_OpeningFcn, ...
                   'gui_OutputFcn',  @Robot_Scara_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end

function Robot_Scara_OpeningFcn(hObject, eventdata, handles, varargin)

global myScara;
global plot_pos;

% SCARA(handles,a1,a2,d1,t1_max,t2_max,d3_max) TOSHIBA THL500
myScara = SCARA(handles,0.2,0.3,0.179,125,145,0.3);
plot_pos = [];

handles.output = hObject;
guidata(hObject, handles);

set(handles.Value_FW_x,'String',num2str(myScara.pos(4,1)));
set(handles.Value_FW_y,'String',num2str(myScara.pos(4,2)));
set(handles.Value_FW_z,'String',num2str(myScara.pos(4,3)));
set(handles.Value_FW_yaw,'String',num2str(myScara.orien(4,3)*180/pi));

ScaraUpdate(myScara,handles,20,25);


% --- Outputs from this function are returned to the command line.
function varargout = Robot_Scara_OutputFcn(hObject, eventdata, handles) 
varargout{1} = handles.output;



function Value_FW_x_Callback(hObject, eventdata, handles)
% --- Executes during object creation, after setting all properties.
function Value_FW_x_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function Value_FW_y_Callback(hObject, eventdata, handles)
% --- Executes during object creation, after setting all properties.

function Value_FW_y_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function Value_FW_z_Callback(hObject, eventdata, handles)

function Value_FW_z_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function Value__FW_y_Callback(hObject, eventdata, handles)
% --- Executes during object creation, after setting all properties.

function Value__FW_y_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Value__FW_z_Callback(hObject, eventdata, handles)
% --- Executes during object creation, after setting all properties.

function Value__FW_z_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function Value_FW_yaw_Callback(hObject, eventdata, handles)

% --- Executes during object creation, after setting all properties.
function Value_FW_yaw_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in btn_Forward.
function btn_Forward_Callback(hObject, eventdata, handles)
    global myScara;
   theta1 = get(handles.Slider_FW_Theta1,'value');
   theta2 = get(handles.Slider_FW_Theta2,'value');
   d3 = get(handles.Slider_FW_d3,'value');
   theta4 = get(handles.Slider_FW_Theta4,'value');

%SCARA_Plot(handles, theta1, theta2, d3, theta4)
myScara = SCARA_Plot(handles,theta1,theta2,d3,theta4);
ScaraUpdate(myScara,handles,20,25);

set(handles.Value__FW_x,'String',num2str(myScara.pos(4,1)));
set(handles.Value__FW_y,'String',num2str(myScara.pos(4,2)));
set(handles.Value__FW_z,'String',num2str(myScara.pos(4,3)));
set(handles.Value__FW_yaw,'String',num2str(myScara.orien(4,3)*180/pi));


% --- Executes on slider movement.

function Slider_FW_Theta1_Callback(hObject, eventdata, handles)
theta1 = get(handles.Slider_FW_Theta1,'value');
set(handles.Value_FW_Theta1,'string',num2str(theta1));

function Slider_FW_Theta1_CreateFcn(hObject, eventdata, handles)
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


function Slider_FW_Theta2_Callback(hObject, eventdata, handles)
theta2 = get(handles.Slider_FW_Theta2,'value');
set(handles.Value_FW_Theta2,'string',num2str(theta2));


% --- Executes during object creation, after setting all properties.
function Slider_FW_Theta2_CreateFcn(hObject, eventdata, handles)
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end

% --- Executes on slider movement.
function Slider_FW_d3_Callback(hObject, eventdata, handles)
d3 = get(handles.Slider_FW_d3,'value');
set(handles.Value_FW_d3,'string',num2str(d3));

function Slider_FW_d3_CreateFcn(hObject, eventdata, handles)
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end

% --- Executes on slider movement.
function Slider_FW_Theta4_Callback(hObject, eventdata, handles)
theta4 = get(handles.Slider_FW_Theta4,'value');
set(handles.Value_FW_Theta4,'string',num2str(theta4));

function Slider_FW_Theta4_CreateFcn(hObject, eventdata, handles)
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end

function Value_FW_Theta1_Callback(hObject, eventdata, handles)
% --- Executes during object creation, after setting all properties.

function Value_FW_Theta1_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function Value_FW_Theta2_Callback(hObject, eventdata, handles)

% --- Executes during object creation, after setting all properties.
function Value_FW_Theta2_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function Value_FW_d3_Callback(hObject, eventdata, handles)
% --- Executes during object creation, after setting all properties.

function Value_FW_d3_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Value_FW_Theta4_Callback(hObject, eventdata, handles)
% --- Executes during object creation, after setting all properties.

function Value_FW_Theta4_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in Checkbox_Ws.
function Checkbox_Ws_Callback(hObject, eventdata, handles)
global myScara
if get(hObject, 'Value')
    PlotWorkspace(myScara,handles);
else
    ScaraUpdate(myScara,handles,20,25);  
end

% --- Executes on button press in Checkbox_Co.
function Checkbox_Co_Callback(hObject, eventdata, handles)
global myScara
if get(hObject, 'Value')
    axes(handles.plot_robot);
    % Plot Coordinate
    A0_1 = Link_matrix(myScara.a(1),myScara.alpha(1)*pi/180,myScara.d(1),myScara.Theta(1)*pi/180) ;
    A1_2 = Link_matrix(myScara.a(2),myScara.alpha(2)*pi/180,myScara.d(2),myScara.Theta(2)*pi/180) ;
    A2_3 = Link_matrix(myScara.a(3),myScara.alpha(3)*pi/180,myScara.d(3),myScara.Theta(3)*pi/180) ;
    A3_4 = Link_matrix(myScara.a(4),myScara.alpha(4)*pi/180,myScara.d(4),myScara.Theta(4)*pi/180) ;
    A0_0=[1 0 0 0; 0 1 0 0; 0 0 1 0; 0 0 0 1];
    A0_2=A0_1*A1_2;
    A0_3=A0_1*A1_2*A2_3;
    A0_4=A0_1*A1_2*A2_3*A3_4;   % Te

    PlotCoordinate(0,0,0+myScara.d(1)*5/4,A0_0,'0');
    PlotCoordinate(myScara.pos(1,1),myScara.pos(1,2),myScara.pos(1,3)+myScara.d(1)*4/4,A0_1,'1');
    PlotCoordinate(myScara.pos(2,1),myScara.pos(2,2),myScara.pos(2,3)+myScara.d(1)*4/4,A0_2,'2');
    PlotCoordinate(myScara.pos(3,1),myScara.pos(3,2),myScara.pos(3,3)+myScara.d(1)*4/4,A0_3,'3');
    PlotCoordinate(myScara.pos(4,1),myScara.pos(4,2),myScara.pos(4,3)+myScara.d(1)*2/4,A0_4,'4');
else
    ScaraUpdate(myScara,handles,22,22); 
end


function Value_a1_Callback(hObject, eventdata, handles)

% --- Executes during object creation, after setting all properties.
function Value_a1_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Value_a2_Callback(hObject, eventdata, handles)

% --- Executes during object creation, after setting all properties.
function Value_a2_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Value_d1_Callback(hObject, eventdata, handles)

% --- Executes during object creation, after setting all properties.
function Value_d1_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
