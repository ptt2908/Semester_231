function ScaraUpdate(robot,handles,Az,El)

global plot_pos

set(handles.Checkbox_Ws,'Value',0);
set(handles.Checkbox_Co,'Value',0);
set(handles.Table_DH,'Data',[robot.d robot.theta robot.a robot.alpha]);    %put dh parameter to DH table
set(handles.Table_Posi_Orien,'Data',[robot.pos robot.orien*180/pi]);   %put PO parameter to PO table

plot_robot = handles.plot_robot;
cla(plot_robot,'reset')
hold(plot_robot,'on')
grid(plot_robot,'on')

if ~isempty(plot_pos)
    plot3(plot_robot,plot_pos(:,1),plot_pos(:,2),plot_pos(:,3),'b','LineWidth',1.5);
end

p0 = [0 0 0];
p1 = robot.pos(1,:);
p2 = robot.pos(2,:);
p3 = robot.pos(3,:);
p4 = robot.pos(4,:);
d = robot.d;
a = robot.a;
orien = robot.orien;

line1=[[p0(1) p1(1)];[p0(2) p1(2)];[p0(3) p1(3)]];
line2=[[p1(1) p2(1)];[p1(2) p2(2)];[p1(3) p2(3)]];
line3=[[p2(1) p3(1)];[p2(2) p3(2)];[p2(3) p3(3)]];
line4=[[p3(1) p4(1)];[p3(2) p4(2)];[p3(3) p4(3)]];

xlabel(plot_robot,'x');
ylabel(plot_robot,'y');
zlabel(plot_robot,'z');


t = (1/16:1/32:1)'*2*pi;
x = (a(1)+a(2))*cos(t);
y = (a(1)+a(2))*sin(t);
z = zeros(length(t),1);
fill3(plot_robot,x,y,z,'g','FaceAlpha',0.25);
view(plot_robot,Az,El)

%Plot_Base
PlotBase(handles,0,0,0,0.24,0.24,0.02,[0.9000 0.0500 0.1250])
PlotCylinder(handles,0,0,0.02,0.12,0.7457*d(1),[0.9000 0.0500 0.1250])

%Plot_Link
%Link1
PlotCylinder(handles,line1(1,1),line1(2,1),0.7826*d(1),0.1,0.0185*d(1),[0.9290 0.6940 0.1250]);
PlotCylinder(handles,line1(1,2),line1(2,2),0.7826*d(1),0.1,0.0185*d(1),[0.9290 0.6940 0.1250]);
PlotCylinder(handles,line1(1,2),line1(2,2),0.8076*d(1),0.1,0.08,[0.9290 0.6940 0.1250]);
PlotCylinder(handles,line1(1,1),line1(2,1),0.8076*d(1),0.1,0.08,[0.9290 0.6940 0.1250]);

[pp1,pp2]=F_Common_Tangent([line1(1,1) line1(2,1)],[line1(1,2) line1(2,2)],0.1,0.1,1,-1);
[pp4,pp3]=F_Common_Tangent([line1(1,1) line1(2,1)],[line1(1,2) line1(2,2)],0.1,0.1,1,1);

fill3(plot_robot,[pp1(1) pp2(1) pp3(1) pp4(1)],[pp1(2) pp2(2) pp3(2) pp4(2)],[0.8076*d(1) 0.8076*d(1) 0.8076*d(1) 0.8076*d(1)],[0.9290 0.6940 0.1250])
fill3(plot_robot,[pp1(1) pp2(1) pp3(1) pp4(1)],[pp1(2) pp2(2) pp3(2) pp4(2)],[0.9815*d(1) 0.9815*d(1) 0.9815*d(1) 0.9815*d(1)],[0.9290 0.6940 0.1250])
fill3(plot_robot,[pp1(1) pp4(1) pp4(1) pp1(1)],[pp1(2) pp4(2) pp4(2) pp1(2)],[0.8076*d(1) 0.8076*d(1) 0.9815*d(1) 0.9815*d(1)],[0.9290 0.6940 0.1250])
fill3(plot_robot,[pp3(1) pp4(1) pp4(1) pp3(1)],[pp3(2) pp4(2) pp4(2) pp3(2)],[0.8076*d(1) 0.8076*d(1) 0.9815*d(1) 0.9815*d(1)],[0.9290 0.6940 0.1250])
fill3(plot_robot,[pp2(1) pp3(1) pp3(1) pp2(1)],[pp2(2) pp3(2) pp3(2) pp2(2)],[0.8076*d(1) 0.8076*d(1) 0.9815*d(1) 0.9815*d(1)],[0.9290 0.6940 0.1250])
fill3(plot_robot,[pp1(1) pp2(1) pp2(1) pp1(1)],[pp1(2) pp2(2) pp2(2) pp1(2)],[0.8076*d(1) 0.8076*d(1) 0.9815*d(1) 0.9815*d(1)],[0.9290 0.6940 0.1250])

%link2
PlotCylinder(handles,line1(1,1),line1(2,1),0.9815*d(1),0.07,0.0185*d(1),[0.9290 0.6940 0.1250]);
PlotCylinder(handles,line1(1,2),line1(2,2),0.9815*d(1),0.11,0.0185*d(1),[0.9290 0.6940 0.1250]);
PlotCylinder(handles,line2(1,1),line2(2,1),0.9815*d(1),0.08,0.8391*d(1)+0.0185*d(1),[0.9290 0.6940 0.1250])
PlotCylinder(handles,line2(1,2),line2(2,2),d(1),0.08,0.1,[0.9290 0.6940 0.1250])

[pp1,pp2]=F_Common_Tangent([line2(1,1) line2(2,1)],[line2(1,2) line2(2,2)],0.08,0.08,1,-1);
[pp4,pp3]=F_Common_Tangent([line2(1,1) line2(2,1)],[line2(1,2) line2(2,2)],0.08,0.08,1,1);

fill3(plot_robot,[pp1(1) pp2(1) pp3(1) pp4(1)],[pp1(2) pp2(2) pp3(2) pp4(2)],[d(1) d(1) d(1) d(1)],[0.9290 0.6940 0.1250])
fill3(plot_robot,[pp1(1) pp2(1) pp3(1) pp4(1)],[pp1(2) pp2(2) pp3(2) pp4(2)],[d(1)+0.1 d(1)+0.1 d(1)+0.1 d(1)+0.1],[0.9290 0.6940 0.1250])
fill3(plot_robot,[pp1(1) pp4(1) pp4(1) pp1(1)],[pp1(2) pp4(2) pp4(2) pp1(2)],[d(1) d(1) d(1)+0.1 d(1)+0.1],[0.9290 0.6940 0.1250])
fill3(plot_robot,[pp3(1) pp4(1) pp4(1) pp3(1)],[pp3(2) pp4(2) pp4(2) pp3(2)],[d(1) d(1) d(1)+0.1 d(1)+0.1],[0.9290 0.6940 0.1250])
fill3(plot_robot,[pp2(1) pp3(1) pp3(1) pp2(1)],[pp2(2) pp3(2) pp3(2) pp2(2)],[d(1) d(1) d(1)+0.1 d(1)+0.1],[0.9290 0.6940 0.1250])
fill3(plot_robot,[pp1(1) pp2(1) pp2(1) pp1(1)],[pp1(2) pp2(2) pp2(2) pp1(2)],[d(1) d(1) d(1)+0.1 d(1)+0.1],[0.9290 0.6940 0.1250])

pp5 = (pp1+pp2)/2;
pp6 = (pp3+pp4)/2;

fill3(plot_robot,[pp1(1) pp5(1) pp5(1) pp1(1)],[pp1(2) pp5(2) pp5(2) pp1(2)],[d(1)+0.1 d(1)+0.1 1.8*d(1) 1.8*d(1)],[0.9290 0.6940 0.1250])
fill3(plot_robot,[pp4(1) pp6(1) pp6(1) pp4(1)],[pp4(2) pp6(2) pp6(2) pp4(2)],[d(1)+0.1 d(1)+0.1 1.8*d(1) 1.8*d(1)],[0.9290 0.6940 0.1250])
fill3(plot_robot,[pp1(1) pp5(1) pp6(1) pp4(1)],[pp1(2) pp5(2) pp6(2) pp4(2)],[1.8*d(1) 1.8*d(1) 1.8*d(1) 1.8*d(1)],[0.9290 0.6940 0.1250])
fill3(plot_robot,[pp5(1) pp2(1) pp5(1)],[pp5(2) pp2(2) pp5(2)],[d(1)+0.1 d(1)+0.1 1.8*d(1)],[0.9290 0.6940 0.1250]);
fill3(plot_robot,[pp6(1) pp3(1) pp6(1)],[pp6(2) pp3(2) pp6(2)],[d(1)+0.1 d(1)+0.1 1.8*d(1)],[0.9290 0.6940 0.1250]);
fill3(plot_robot,[pp5(1) pp2(1) pp3(1) pp6(1)],[pp5(2) pp2(2) pp3(2) pp6(2)],[1.8*d(1) d(1)+0.1 d(1)+0.1 1.8*d(1)],[0.9290 0.6940 0.1250])


% %link3
PlotCylinder(handles,p2(1),p2(2),d(1)-0.02,0.05,0.02,[0.4660 0.6740 0.1880])
PlotCylinder(handles,p2(1),p2(2),d(1)-0.035,0.02,0.015,[0.4660 0.6740 0.1880])
PlotCylinder(handles,p3(1),p3(2),p3(3),0.02,1.4*d(1),[0 0 0]);
PlotCylinder(handles,p3(1),p3(2),p3(3)+1.4*d(1),0.03,0.03,[0 0 0]);

for i=0:pi/4:3*pi/4
    picker(handles,p4(1),p4(2),p4(3),orien(4,3)*pi/180+i,0.15,0.05);
end
view(plot_robot,Az,El)
axis(plot_robot,'equal')
%end