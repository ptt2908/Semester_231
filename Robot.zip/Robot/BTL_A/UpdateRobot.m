function UpdateRobot(robot,handles,Az,El)
% Az la de dieu chinh huong quay quanh truc z
% El la de dieu chinh huong quay quanh truc y
global plot_pos


robot_plot = handles.robot_plot;
cla(robot_plot,'reset')
hold(robot_plot,'on')
grid(robot_plot,'on')

p0 = [0 0 0];
p1 = robot.pos(1,:);
p2 = robot.pos(2,:);
p3 = robot.pos(3,:);
p4 = robot.pos(4,:);
d = robot.d;
a = robot.a;
orien = robot.orien;

% define links
line1=[[p0(1) p1(1)];[p0(2) p1(2)];[p0(3) p1(3)]];
line2=[[p1(1) p2(1)];[p1(2) p2(2)];[p1(3) p2(3)]];
line3=[[p2(1) p3(1)];[p2(2) p3(2)];[p2(3) p3(3)]];
line4=[[p3(1) p4(1)];[p3(2) p4(2)];[p3(3) p4(3)]];

xlabel(robot_plot,'x');
ylabel(robot_plot,'y');
zlabel(robot_plot,'z');


% Ve base
VeHop(handles,0,0,0,0.24,0.24,0.02,[0.9290 0.6940 0.1250])
VeHinhTru(handles,0,0,0.02,0.12,0.7457*d(1),[0.9290 0.6940 0.1250])
% 
% %link 1
VeHinhTru(handles,line1(1,1),line1(2,1),0.7826*d(1),0.1,0.0185*d(1),[0.9290 0.6940 0.1250]);
VeHinhTru(handles,line1(1,2),line1(2,2),0.7826*d(1),0.1,0.0185*d(1),[0.9290 0.6940 0.1250]);
VeHinhTru(handles,line1(1,2),line1(2,2),0.8076*d(1),0.1,0.08,[0.9290 0.6940 0.1250]);
VeHinhTru(handles,line1(1,1),line1(2,1),0.8076*d(1),0.1,0.08,[0.9290 0.6940 0.1250]);

[pp1,pp2]=F_Common_Tangent([line1(1,1) line1(2,1)],[line1(1,2) line1(2,2)],0.1,0.1,1,-1);
[pp4,pp3]=F_Common_Tangent([line1(1,1) line1(2,1)],[line1(1,2) line1(2,2)],0.1,0.1,1,1);

fill3(robot_plot,[pp1(1) pp2(1) pp3(1) pp4(1)],[pp1(2) pp2(2) pp3(2) pp4(2)],[0.8076*d(1) 0.8076*d(1) 0.8076*d(1) 0.8076*d(1)],[0.9290 0.6940 0.1250])
fill3(robot_plot,[pp1(1) pp2(1) pp3(1) pp4(1)],[pp1(2) pp2(2) pp3(2) pp4(2)],[0.9815*d(1) 0.9815*d(1) 0.9815*d(1) 0.9815*d(1)],[0.9290 0.6940 0.1250])
fill3(robot_plot,[pp1(1) pp4(1) pp4(1) pp1(1)],[pp1(2) pp4(2) pp4(2) pp1(2)],[0.8076*d(1) 0.8076*d(1) 0.9815*d(1) 0.9815*d(1)],[0.9290 0.6940 0.1250])
fill3(robot_plot,[pp3(1) pp4(1) pp4(1) pp3(1)],[pp3(2) pp4(2) pp4(2) pp3(2)],[0.8076*d(1) 0.8076*d(1) 0.9815*d(1) 0.9815*d(1)],[0.9290 0.6940 0.1250])
fill3(robot_plot,[pp2(1) pp3(1) pp3(1) pp2(1)],[pp2(2) pp3(2) pp3(2) pp2(2)],[0.8076*d(1) 0.8076*d(1) 0.9815*d(1) 0.9815*d(1)],[0.9290 0.6940 0.1250])
fill3(robot_plot,[pp1(1) pp2(1) pp2(1) pp1(1)],[pp1(2) pp2(2) pp2(2) pp1(2)],[0.8076*d(1) 0.8076*d(1) 0.9815*d(1) 0.9815*d(1)],[0.9290 0.6940 0.1250])

% 
%link2
VeHinhTru(handles,line1(1,1),line1(2,1),0.9815*d(1),0.07,0.0185*d(1),[0.9290 0.6940 0.1250]);
VeHinhTru(handles,line1(1,2),line1(2,2),0.9815*d(1),0.11,0.0185*d(1),[0.9290 0.6940 0.1250]);
VeHinhTru(handles,line2(1,1),line2(2,1),0.9815*d(1),0.08,0.8391*d(1)+0.0185*d(1),[0.9290 0.6940 0.1250])
VeHinhTru(handles,line2(1,2),line2(2,2),d(1),0.08,0.1,[0.9290 0.6940 0.1250])

[pp1,pp2]=F_Common_Tangent([line2(1,1) line2(2,1)],[line2(1,2) line2(2,2)],0.08,0.08,1,-1);
[pp4,pp3]=F_Common_Tangent([line2(1,1) line2(2,1)],[line2(1,2) line2(2,2)],0.08,0.08,1,1);

fill3(robot_plot,[pp1(1) pp2(1) pp3(1) pp4(1)],[pp1(2) pp2(2) pp3(2) pp4(2)],[d(1) d(1) d(1) d(1)],[0.9290 0.6940 0.1250])
fill3(robot_plot,[pp1(1) pp2(1) pp3(1) pp4(1)],[pp1(2) pp2(2) pp3(2) pp4(2)],[d(1)+0.1 d(1)+0.1 d(1)+0.1 d(1)+0.1],[0.9290 0.6940 0.1250])
fill3(robot_plot,[pp1(1) pp4(1) pp4(1) pp1(1)],[pp1(2) pp4(2) pp4(2) pp1(2)],[d(1) d(1) d(1)+0.1 d(1)+0.1],[0.9290 0.6940 0.1250])
fill3(robot_plot,[pp3(1) pp4(1) pp4(1) pp3(1)],[pp3(2) pp4(2) pp4(2) pp3(2)],[d(1) d(1) d(1)+0.1 d(1)+0.1],[0.9290 0.6940 0.1250])
fill3(robot_plot,[pp2(1) pp3(1) pp3(1) pp2(1)],[pp2(2) pp3(2) pp3(2) pp2(2)],[d(1) d(1) d(1)+0.1 d(1)+0.1],[0.9290 0.6940 0.1250])
fill3(robot_plot,[pp1(1) pp2(1) pp2(1) pp1(1)],[pp1(2) pp2(2) pp2(2) pp1(2)],[d(1) d(1) d(1)+0.1 d(1)+0.1],[0.9290 0.6940 0.1250])

pp5 = (pp1+pp2)/2;
pp6 = (pp3+pp4)/2;

fill3(robot_plot,[pp1(1) pp5(1) pp5(1) pp1(1)],[pp1(2) pp5(2) pp5(2) pp1(2)],[d(1)+0.1 d(1)+0.1 1.8*d(1) 1.8*d(1)],[0.9290 0.6940 0.1250])
fill3(robot_plot,[pp4(1) pp6(1) pp6(1) pp4(1)],[pp4(2) pp6(2) pp6(2) pp4(2)],[d(1)+0.1 d(1)+0.1 1.8*d(1) 1.8*d(1)],[0.9290 0.6940 0.1250])
fill3(robot_plot,[pp1(1) pp5(1) pp6(1) pp4(1)],[pp1(2) pp5(2) pp6(2) pp4(2)],[1.8*d(1) 1.8*d(1) 1.8*d(1) 1.8*d(1)],[0.9290 0.6940 0.1250])
fill3(robot_plot,[pp5(1) pp2(1) pp5(1)],[pp5(2) pp2(2) pp5(2)],[d(1)+0.1 d(1)+0.1 1.8*d(1)],[0.9290 0.6940 0.1250]);
fill3(robot_plot,[pp6(1) pp3(1) pp6(1)],[pp6(2) pp3(2) pp6(2)],[d(1)+0.1 d(1)+0.1 1.8*d(1)],[0.9290 0.6940 0.1250]);
fill3(robot_plot,[pp5(1) pp2(1) pp3(1) pp6(1)],[pp5(2) pp2(2) pp3(2) pp6(2)],[1.8*d(1) d(1)+0.1 d(1)+0.1 1.8*d(1)],[0.9290 0.6940 0.1250])


% %link3
VeHinhTru(handles,p2(1),p2(2),d(1)-0.02,0.05,0.02,[0.4660 0.6740 0.1880])
VeHinhTru(handles,p2(1),p2(2),d(1)-0.035,0.02,0.015,[0.4660 0.6740 0.1880])
VeHinhTru(handles,p3(1),p3(2),p3(3),0.02,1.4*d(1),[0 0 0]);
VeHinhTru(handles,p3(1),p3(2),p3(3)+1.4*d(1),0.03,0.03,[0 0 0]);


%gioi han do dai cac truc
xlim(robot_plot,[-1 1]);
ylim(robot_plot,[-1 1]);
zlim(robot_plot,[0 0.5]);
view(robot_plot,Az,El)
%axis(robot_plot,'equal')