function ResetRobot(handles)

set(handles.sld__FW_t1, 'value', 0);
set(handles.sld__FW_t2, 'value', 90);
set(handles.sld__FW_d3, 'value', 0);
set(handles.sld__FW_t4, 'value', 0);
set(handles.vl__FW_t1,'string','0');
set(handles.vl__FW_t2,'string','90');
set(handles.vl__FW_d3,'string','0');
set(handles.vl__FW_t4,'string','-90');

set(handles.vl__IV_x,'String','0.45');
set(handles.vl__IV_y,'String','0.40');
set(handles.vl__IV_z,'String','0.46');
set(handles.vl__IV_yaw,'String','90');