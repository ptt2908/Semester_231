classdef SCARA
    %UNTITLED2 Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        %% DH parameter
        a;
        d;
        alpha;  % unit deg
        theta;  % unit deg
        
        %% Limatation of workspace
        pos;    %%position of 4 joints 1 2 3 4
        orien;  %%orientation of 4 joints 1 2 3 4, unit radian
    end
    
    methods(Static)
        function obj = SCARA(handles, the1, the2, d3, the4)
            obj.a = [0.3; 0.3; 0; 0];
            obj.d = [0.179; 0; 0; 0];
            obj.alpha = [0.00; 0.00; 0.00; 180];
            obj.theta = [0.00; 0.00; 0.00; 0.00];
            obj.d(3)=d3;
            obj.theta(1)=the1;
            obj.theta(2)=the2;
            obj.theta(4)=the4;
            [obj.pos,obj.orien] = obj.ForwardKinematic(obj);  
        end
        
        function [p_robot,o_robot] = ForwardKinematic(self)
            a = self.a;
            alpha = self.alpha*pi/180;
            d = self.d;
            theta = self.theta*pi/180;
            
            %% Ham tinh dong hoc thuan c?a robot
            % Input: DH Parameter
            % Output: joint position p1 p2 p3 p4     (x y z)
            %         joint orientation o1 o2 o3 o4  (roll pitch yaw)
            %% FK Matrix
            A0_1 = Matran_A(a(1),alpha(1),d(1),theta(1)) ;
            A1_2 = Matran_A(a(2),alpha(2),d(2),theta(2)) ;
            A2_3 = Matran_A(a(3),alpha(3),d(3),theta(3)) ;
            A3_4 = Matran_A(a(4),alpha(4),d(4),theta(4)) ;

            A0_2=A0_1*A1_2;
            A0_3=A0_1*A1_2*A2_3;
            A0_4=A0_1*A1_2*A2_3*A3_4;   % Te

            p0 = [0;0;0];
            [p1, o1] = cal_pose(A0_1,p0);
            [p2, o2] = cal_pose(A0_2,p0);
            [p3, o3] = cal_pose(A0_3,p0);
            [p4, o4] = cal_pose(A0_4,p0);

            p_robot = [p1 p2 p3 p4]';
            o_robot = [o1; o2; o3; o4];
        end
        
    end
end

